import express from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Doctor from "../models/doctor.js"; 

const router = express.Router();

router.post("/register", async (req, res) => {
     console.log("Register route hit!", req.body);
  try {
    const { username, name, email, password } = req.body;

    // Server-side validation
    if (!username || !name || !email || !password) {
      return res.status(400).json({ message: "Please fill out all fields." });
    }

    const existingDoctor = await Doctor.findOne({ $or: [{ email }, { username }] });
    if (existingDoctor) {
      return res.status(400).json({ message: "Username or email already exists." });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const newDoctor = new Doctor({ username, name, email, password: hashedPassword });
    await newDoctor.save();

    res.status(201).json({ message: "Doctor registered successfully. Please login." });
  } catch (err) {
    console.error("REGISTRATION ERROR:", err);
    res.status(500).json({ message: "Server error during registration. Please check server logs." });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: "Please provide username and password."});
    }

    const doctor = await Doctor.findOne({ username });
    if (!doctor) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, doctor.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ id: doctor._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

    res.json({ token, doctor: { id: doctor._id, name: doctor.name, email: doctor.email } });
  } catch (err) {
    console.error("LOGIN ERROR:", err);
    res.status(500).json({ message: "Server error during login." });
  }
});

export default router;

